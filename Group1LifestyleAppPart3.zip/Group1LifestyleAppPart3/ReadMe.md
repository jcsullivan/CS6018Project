**CS6018  
Group 1**  

**Team Lead:**  Sam Bauter  
**Test Lead:**  Bob Allen  
**Design Lead:**  Jonathan Sullivan  

**NOTE:**  The basic-app-debug.apk and basic-app-release.apk files contain the project as it was before the implementation of AWS and Amplify, and should work just fine.  The amplify-app-debug.apk and amplify-release-app.apk files include those additions, and may or may not work properly on your emulator, due to issues encountered with Amplify itself.  Please attempt to register regardless and see what happens!  If it doesn't work, we can schedule a time to demonstrate it on Sam's machine.  