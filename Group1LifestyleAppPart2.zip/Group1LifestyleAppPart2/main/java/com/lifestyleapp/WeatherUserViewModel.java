package com.lifestyleapp;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class WeatherUserViewModel extends AndroidViewModel {

    private MutableLiveData<User> userMutableLiveData;
    private UserRepository userRepository;

    public WeatherUserViewModel (Application application) {

        super(application);

        userRepository = UserRepository.getInstance();

        userMutableLiveData = userRepository.getUserData();

    }

    // FORWARD ALL OF THE DATA TO THE REPOSITORY
    public void setProfileViewModelData(String fullName, int age, String city, String country, double height, double weight, int gender, String photoLocation, int photoSize, double bmi, double bmr, boolean sedentary){
        userRepository.setUserData(fullName, age, city, country, height, weight, gender, photoLocation, photoSize, bmi, bmr, sedentary);
    }

    // RETRIEVE DATA FROM THE REPOSITORY
    public LiveData<User> getProfileViewModelData() {
        return userRepository.getUserData();
    }

}