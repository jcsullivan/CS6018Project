**Group 1:**  
Team Lead - Bob Allan  
Test Lead - Jonathan Sullivan  
Design Lead - Sam Bauter  

**Please note:**  
app-debug is not signed, while app-release is signed.  Both should be identical programs, aside from that difference.  